from math import log
import operator
import numpy
import csv
import re
import linecache
import numpy as np
import os

 
 
"""
函数说明:创建测试数据集
"""
def createDataSet():
    dataSet = [[1015425,3,1,1,1,2,2,3,1,1,2],
               [1016277,6,8,8,1,3,4,3,7,1,2],              
               [1018561,2,1,2,1,2,1,3,1,1,2],
               [1033078,2,1,1,1,2,1,1,1,5,2],              
               [1033078,4,2,1,1,2,1,2,1,1,2],
               [1035283,1,1,1,1,1,1,3,1,1,2],              
               [1036172,2,1,1,1,2,1,2,1,1,2],
               [1041801,5,3,3,3,2,3,4,4,1,4],              
               [1043999,1,1,1,1,2,3,3,1,1,2],
               [1044572,8,7,5,10,7,9,5,5,4,4],
               [1047630,7,4,6,4,6,1,4,3,1,4],
               [1048672,4,1,1,1,2,1,2,1,1,2],              
               [1049815,4,1,1,1,2,1,3,1,1,2]]
    labels =['Samplecodenumber','ClumpThickness', 'UniformityofCellSize', 'UniformityofCellShape', 'MarginalAdhesion','SingleEpithelialCellSize','BareNuclei','BlandChromatin','NormalNucleoli','Mitoses']        #分类属性
    return dataSet, labels                        
      
    

"""
Function description: Calculate the empirical entropy of a given data set
Parameters:
     dataSet-data set
Returns:
     shannonEnt-empirical entropy (Shannon Entropy)
"""
def calcShannonEnt(dataSet):
    numEntires = len(dataSet)                        
    labelCounts = {}                                 
    for featVec in dataSet:                         
        currentLabel = featVec[-1]                   
        if currentLabel not in labelCounts.keys():   
            labelCounts[currentLabel] = 0
        labelCounts[currentLabel] += 1               
    shannonEnt = 0.0                                 
    for key in labelCounts:                          
        prob = float(labelCounts[key]) / numEntires  
        shannonEnt -= prob * log(prob, 2)            
    return shannonEnt                                
 
 
"""
Function description: divide the data set according to the given characteristics
Parameters:
     dataSet-the data set to be divided
     axis-divide the features of the data set
     value-the value of the feature to be returned
"""
def splitDataSet(dataSet, axis, value):
    retDataSet = []                                     
    for featVec in dataSet:                             
        if featVec[axis] == value:
            reducedFeatVec = featVec[:axis]             
            reducedFeatVec.extend(featVec[axis+1:])     
            retDataSet.append(reducedFeatVec)
    return retDataSet                                   
 
 
"""
Function description: select the best feature
Parameters:
     dataSet-data set
Returns:
     bestFeature-the index value of the (optimal) feature with the largest information gain
"""
def chooseBestFeatureToSplit(dataSet):
    numFeatures = len(dataSet[0]) - 1                     
    baseEntropy = calcShannonEnt(dataSet)                 
    bestInfoGain = 0.0                                    
    bestFeature = -1                                      
    for i in range(numFeatures):                          
        featList = [example[i] for example in dataSet]
        uniqueVals = set(featList)                         
        newEntropy = 0.0                                  
        for value in uniqueVals:                           
            subDataSet = splitDataSet(dataSet, i, value)           
            prob = len(subDataSet) / float(len(dataSet))           
            newEntropy += prob * calcShannonEnt(subDataSet)        
        infoGain = baseEntropy - newEntropy                        #Information gain
        print("The gain of the %d feature is %.3f" % (i, infoGain))             
        if (infoGain > bestInfoGain):                              
            bestInfoGain = infoGain                                
            bestFeature = i                                       
    return bestFeature                                             
 
 
"""
Function description: Count the most elements (class tags) that appear here in classList
Parameters:
     classList-List of class tags
Returns:
     sortedClassCount[0][0]-the element that appears the most here (class label)
"""
def majorityCnt(classList):
    classCount = {}
    for vote in classList:                                        
        if vote not in classCount.keys():
            classCount[vote] = 0
        classCount[vote] += 1
    sortedClassCount = sorted(classCount.items(), key = operator.itemgetter(1), reverse = True)      
    return sortedClassCount[0][0]                                
 
 
"""
Function description: Recursively build a decision tree
Parameters:
     dataSet-training data set
     labels-Classification attribute labels
     featLabels-stores the selected optimal feature labels
Returns:
     myTree-decision tree
"""
def createTree(dataSet, labels, featLabels):
    classList = [example[-1] for example in dataSet]               
    if classList.count(classList[0]) == len(classList):            
        return classList[0]
    if len(dataSet[0]) == 1:                                       
        return majorityCnt(classList)
    bestFeat = chooseBestFeatureToSplit(dataSet)                   
    bestFeatLabel = labels[bestFeat]                               
    featLabels.append(bestFeatLabel)
    myTree = {bestFeatLabel:{}}                                    
    del(labels[bestFeat])                                          
    featValues = [example[bestFeat] for example in dataSet]        
    uniqueVals = set(featValues)                                   
    for value in uniqueVals:
        subLabels=labels[:]
        myTree[bestFeatLabel][value] = createTree(splitDataSet(dataSet, bestFeat, value), subLabels, featLabels)
    return myTree
 
 
def classify(inputTree, featLabels, testVec):
    firstStr = next(iter(inputTree))             
    secondDict = inputTree[firstStr]             
    featIndex = featLabels.index(firstStr)
    for key in secondDict.keys():
        if testVec[featIndex] == key:
            if type(secondDict[key]).__name__ == 'dict':
                classLabel = classify(secondDict[key], featLabels, testVec)
            else:
                classLabel = secondDict[key]
    return classLabel


    return classLabel
 
 

 
if __name__ == '__main__':
    dataSet, labels = createDataSet()
    featLabels = []
    myTree = createTree(dataSet, labels, featLabels)
    print(myTree)
    testVec = [1033078,4,2,1,1,2,1,2,1,1]     # test
    result = classify(myTree, featLabels, testVec)
    if result == '2':
        print('Benign')
    if result == '4':
        print('Malignant')
 
